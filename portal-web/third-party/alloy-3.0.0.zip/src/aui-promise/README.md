aui-promise
========
